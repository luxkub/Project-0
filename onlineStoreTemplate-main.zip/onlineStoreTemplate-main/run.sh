# export the flask app and run it
export FLASK_APP=app.py
flask run